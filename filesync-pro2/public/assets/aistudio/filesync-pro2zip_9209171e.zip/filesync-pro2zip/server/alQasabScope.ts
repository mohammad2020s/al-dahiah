export interface LandmarkLocation {
  id: string;
  name: string;
  category: string;
  address: string;
  description: string;
  geocodingQuery: string;
  directionsUrl: string;
  coordinates: {
    lat: number;
    lng: number;
  };
}

export interface DrivingRouteGuide {
  id: string;
  fromName: string;
  toName: string;
  distanceKm: number;
  estimatedDuration: string;
  recommendedRoad: string;
  steps: string[];
  googleMapsUrl: string;
}

export const AL_QASAB_ROUTES: DrivingRouteGuide[] = [
  {
    id: "riyadh_salboukh",
    fromName: "الرياض (عبر طريق صلبوخ / حريملاء)",
    toName: "مدينة القصب وموسم الملح",
    distanceKm: 155,
    estimatedDuration: "ساعة و40 دقيقة تقريباً",
    recommendedRoad: "طريق الملك فهد شمالاً -> طريق صلبوخ (طريق 535) -> حريملاء -> رغبة -> القصب (طريق 505)",
    steps: [
      "الانطلاق من الرياض شمالاً عبر طريق الملك فهد باتجاه صلبوخ.",
      "متابعة السير عبر طريق حريملاء (طريق 535) مروراً بمحافظة حريملاء ثم رغبة.",
      "الاستمرار حتى الوصول إلى مدخل القصب على طريق 505 (طريق شقراء - القصب).",
      "اتباع اللوحات الإرشادية لقرية القصب التراثية ومقر موسم الملح."
    ],
    googleMapsUrl:
      "https://www.google.com/maps/dir/?api=1&origin=Riyadh&destination=25.298445880677342,45.507267904132114&travelmode=driving",
  },
  {
    id: "riyadh_makkah_highway",
    fromName: "الرياض (عبر طريق مكة السريع / مرات)",
    toName: "مدينة القصب ومملحة القصب",
    distanceKm: 170,
    estimatedDuration: "ساعة و45 دقيقة تقريباً",
    recommendedRoad: "طريق مكة المكرمة السريع (طريق 40) -> مخرج مرات -> مرات -> ثرمداء -> القصب",
    steps: [
      "سلك طريق مكة المكرمة السريع غرباً (طريق 40).",
      "الخروج عبر مخرج ضرما / مرات إلى طريق 505.",
      "المرور بمحافظة مرات وثرمداء وصولاً إلى القصب.",
      "مقر الفعاليات والمملحة يبعد دقائق معدودة من المدخل الغربي."
    ],
    googleMapsUrl:
      "https://www.google.com/maps/dir/?api=1&origin=Riyadh&destination=25.298445880677342,45.507267904132114&waypoints=Marat,Saudi+Arabia&travelmode=driving",
  },
  {
    id: "shaqra_qasab",
    fromName: "محافظة شقراء",
    toName: "مدينة القصب",
    distanceKm: 35,
    estimatedDuration: "25 دقيقة فقط",
    recommendedRoad: "طريق الملك عبدالعزيز (طريق 505 الرابط بين شقراء والقصب)",
    steps: [
      "الخروج من شقراء شرقاً عبر طريق القصب (طريق 505).",
      "طريق مزدوج وسريع لمسافة 35 كم حتى الدخول في نطاق مدينة القصب.",
      "الموسم والقرية التراثية على يمين الطريق الرئيسي."
    ],
    googleMapsUrl:
      "https://www.google.com/maps/dir/?api=1&origin=Shaqra&destination=25.298445880677342,45.507267904132114&travelmode=driving",
  },
  {
    id: "qasab_to_saltflats",
    fromName: "مركز مدينة القصب",
    toName: "ممالح القصب التاريخية (الجفار)",
    distanceKm: 4.5,
    estimatedDuration: "6 دقائق",
    recommendedRoad: "طريق الممالح المعبد جنوب شرق المدينة",
    steps: [
      "التحرك جنوب شرق المدينة باتجاه سبخة القصب الشهيرة.",
      "طريق معبد ومضاء يوصلك مباشرة إلى أحواض التبخير وقرية الملح القديمة.",
      "الموقع متاح للزيارة والتصوير والاطلاع على استخراج الملح الطبيعي."
    ],
    googleMapsUrl:
      "https://www.google.com/maps/dir/?api=1&origin=25.298445880677342,45.507267904132114&destination=25.261511229205617,45.5518962488553&travelmode=driving",
  },
  {
    id: "majmaah_qasab",
    fromName: "محافظة المجمعة",
    toName: "مدينة القصب",
    distanceKm: 85,
    estimatedDuration: "55 دقيقة",
    recommendedRoad: "طريق المجمعة - شقراء -> مفرق القصب",
    steps: [
      "الانطلاق جنوباً عبر طريق الوشم.",
      "المرور بجلاجل وأشيقر ثم الاتجاه عبر طريق 505.",
      "الوصول إلى القصب عبر المدخل الشمالي."
    ],
    googleMapsUrl:
      "https://www.google.com/maps/dir/?api=1&origin=Al+Majma'ah&destination=25.298445880677342,45.507267904132114&travelmode=driving",
  },
];

export const GOOGLE_MAPS_COFFEE_URL =
  "https://www.google.com/maps/search/coffee/@25.2994467,45.5111576,2237m/data=!3m1!1e3?entry=ttu&g_ep=EgoyMDI2MDkwMS4wIKXMDSoASAFQAw%3D%3D";

export const AL_QASAB_LANDMARKS: LandmarkLocation[] = [
  {
    id: "festival",
    name: "مقر موسم ملح القصب (أرض الفعاليات)",
    category: "فعاليات ومواسم",
    address: "مدينة القصب - أرض الفعاليات التراثية (إحداثيات: 25.298446, 45.507268)",
    description: "مقر احتفالات وفعاليات موسم ملح القصب السنوي والمعارض التراثية والأسواق الشعبية.",
    geocodingQuery: "25.298445880677342, 45.507267904132114",
    directionsUrl:
      "https://www.google.com/maps/dir/?api=1&destination=25.298445880677342,45.507267904132114",
    coordinates: {
      lat: 25.298445880677342,
      lng: 45.507267904132114,
    },
  },
  {
    id: "salt_flat",
    name: "ممالح القصب التاريخية والجفار",
    category: "معالم طبيعية وتراثية",
    address: "جنوب شرق مدينة القصب (4-5 كم)",
    description: "أشهر وأعرق ملاحات طبيعية في الجزيرة العربية لاستخراج الملح الصخري النقي منذ مئات السنين.",
    geocodingQuery: "25.261511229205617, 45.5518962488553",
    directionsUrl:
      "https://www.google.com/maps/dir/?api=1&destination=25.261511229205617,45.5518962488553",
    coordinates: {
      lat: 25.261511229205617,
      lng: 45.5518962488553,
    },
  },
  {
    id: "sabkha",
    name: "سبخة القصب الطبيعية",
    category: "معالم طبيعية",
    address: "سبخة القصب - إقليم الوشم",
    description: "سبخة طبيعية تمتاز بانخفاض درجات الحرارة ليلاً في الصيف بمقدار 5 إلى 10 درجات مئوية.",
    geocodingQuery: "25.27544, 45.4807078",
    directionsUrl: "https://maps.app.goo.gl/HkziBCjrVqomTmop7",
    coordinates: {
      lat: 25.27544,
      lng: 45.4807078,
    },
  },
  {
    id: "heritage_village",
    name: "قرية القصب التراثية (الديرة القديمة)",
    category: "تراث وعمارة طينية",
    address: "وسط القصب القديمة",
    description: "مبانٍ طينية نجدية أصيلة، أزقة تاريخية ومجالس تراثية تعكس تاريخ أهل القصب العريق.",
    geocodingQuery: "25.29880, 45.50650",
    directionsUrl:
      "https://www.google.com/maps/dir/?api=1&destination=25.29880,45.50650",
    coordinates: {
      lat: 25.2988,
      lng: 45.5065,
    },
  },
  {
    id: "ibn_zahim_palace",
    name: "قصر ابن زاحم التاريخي",
    category: "قصور وقلاع تاريخية",
    address: "القصب القديمة",
    description: "أحد أبرز القصور التاريخية والمعالم الشامخة في القصب الدالة على كرم وريادة أهلها.",
    geocodingQuery: "25.29870, 45.50790",
    directionsUrl:
      "https://www.google.com/maps/dir/?api=1&destination=25.29870,45.50790",
    coordinates: {
      lat: 25.2987,
      lng: 45.5079,
    },
  },
  {
    id: "al_marqab",
    name: "برج المرقب الأثري بالقصب",
    category: "أبراج مراقبة تاريخية",
    address: "مطل القصب الشرقي",
    description: "برج مراقبة طيني تاريخي شهير كان يُستخدم لحماية البلدة وتأمين القوافل التجارية قديماً.",
    geocodingQuery: "25.29950, 45.51220",
    directionsUrl:
      "https://www.google.com/maps/dir/?api=1&destination=25.29950,45.51220",
    coordinates: {
      lat: 25.2995,
      lng: 45.5122,
    },
  },
  {
    id: "cafes",
    name: "مقاهي وديوانيات القصب التراثية (4 مقاهٍ معتمدة)",
    category: "ضيافة ومقاهٍ",
    address: "نطاق القرية التراثية بالقصب",
    description: "أبرز مقاهي القصب: قهوة بدور إبراهيم (4.9 نجوم)، شاهي ناقع (4.7 نجوم)، آرت كافيه (4.8 نجوم)، ديوانية المنيع (4.8 نجوم).",
    geocodingQuery: "coffee near Al Qasab 25.2994467, 45.5111576",
    directionsUrl: GOOGLE_MAPS_COFFEE_URL,
    coordinates: {
      lat: 25.2994467,
      lng: 45.5111576,
    },
  },
];

export interface CafePlace {
  id: string;
  name: string;
  category: string;
  rating: number;
  reviewsCount?: number;
  description: string;
  locationDescription: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  directionsUrl: string;
}

export const AL_QASAB_CAFES: CafePlace[] = [
  {
    id: "bdor_coffee",
    name: "قهوة بدور إبراهيم (Bdor Coffee)",
    category: "قهوة سعودية وحلويات شعبية",
    rating: 4.9,
    reviewsCount: 185,
    description: "قهوة سعودية أصيلة بالهيل والزعفران، وحلويات شعبية مميزة في أجواء قرية القصب التراثية.",
    locationDescription: "داخل القرية التراثية بالقصب",
    coordinates: {
      lat: 25.2991008,
      lng: 45.5061342,
    },
    directionsUrl: "https://maps.app.goo.gl/KxaK5XDUQ48qpFgJ7",
  },
  {
    id: "art_coffee",
    name: "آرت كافيه (Art Coffee)",
    category: "قهوة مختصة وعصرية",
    rating: 4.8,
    reviewsCount: 240,
    description: "مقهى راقٍ للقهوة المختصة (V60 وإسبريسو) وجلسات عصرية فنية بالقصب.",
    locationDescription: "شارع القصب العام بجوار البلدة القديمة",
    coordinates: {
      lat: 25.2997841,
      lng: 45.5051558,
    },
    directionsUrl: "https://maps.app.goo.gl/ywM6qBuz57z79RHFA",
  },
  {
    id: "shahi_nagea",
    name: "شاهي ناقع (Shahi Nagea)",
    category: "شاي على الحطب ومشروبات ساخنة",
    rating: 4.7,
    reviewsCount: 160,
    description: "شاي مخدر على الحطب بنكهات نجدية ونعناع حساوي وجلسات شعبية دافئة.",
    locationDescription: "مدخل القرية التراثية بالقصب",
    coordinates: {
      lat: 25.2992775,
      lng: 45.5061188,
    },
    directionsUrl: "https://maps.app.goo.gl/uPAzmcUFzPSpYuHp9",
  },
  {
    id: "diwaniyat_al_manie",
    name: "ديوانية المنيع التراثية",
    category: "مجلس ضيافة تراثي",
    rating: 4.8,
    reviewsCount: 125,
    description: "مجلس ضيافة تراثي نجدي لاستقبال الضيوف وتقديم القهوة والشاي والتمر السكري الفاخر.",
    locationDescription: "حي المنيع بالقرب من قصر ابن زاحم",
    coordinates: {
      lat: 25.2996014,
      lng: 45.5066172,
    },
    directionsUrl: "https://maps.app.goo.gl/qEsUJGRkCrnGWokv6",
  },
];

export const FESTIVAL_LOCATION = {
  ...AL_QASAB_LANDMARKS[0],
  type: "festival" as const,
  landmarks: AL_QASAB_LANDMARKS,
  routes: AL_QASAB_ROUTES,
};

export const SALT_FLAT_LOCATION = {
  ...AL_QASAB_LANDMARKS[1],
  type: "salt_flat" as const,
  landmarks: AL_QASAB_LANDMARKS,
  routes: AL_QASAB_ROUTES,
};

export const SABKHA_LOCATION = {
  ...AL_QASAB_LANDMARKS[2],
  type: "sabkha" as const,
  landmarks: AL_QASAB_LANDMARKS,
  routes: AL_QASAB_ROUTES,
};

export const HERITAGE_VILLAGE_LOCATION = {
  ...AL_QASAB_LANDMARKS[3],
  type: "heritage_village" as const,
  landmarks: AL_QASAB_LANDMARKS,
  routes: AL_QASAB_ROUTES,
};

export const IBN_ZAHIM_LOCATION = {
  ...AL_QASAB_LANDMARKS[4],
  type: "ibn_zahim" as const,
  landmarks: AL_QASAB_LANDMARKS,
  routes: AL_QASAB_ROUTES,
};

export const AL_MARQAB_LOCATION = {
  ...AL_QASAB_LANDMARKS[5],
  type: "al_marqab" as const,
  landmarks: AL_QASAB_LANDMARKS,
  routes: AL_QASAB_ROUTES,
};

export const CAFES_LOCATION = {
  name: "مقاهي وديوانيات القصب التراثية",
  address: "مدينة القصب - منطقة القرية التراثية",
  geocodingQuery: "coffee near Al Qasab 25.2994467, 45.5111576",
  directionsUrl: GOOGLE_MAPS_COFFEE_URL,
  coordinates: {
    lat: 25.2994467,
    lng: 45.5111576,
  },
  type: "cafes" as const,
  places: AL_QASAB_CAFES,
  landmarks: AL_QASAB_LANDMARKS,
  routes: AL_QASAB_ROUTES,
};

export const BDOR_COFFEE_LOCATION = {
  ...AL_QASAB_CAFES[0],
  address: "القرية التراثية - القصب",
  geocodingQuery: "25.2991008, 45.5061342",
  type: "cafes" as const,
  places: [AL_QASAB_CAFES[0]],
  landmarks: AL_QASAB_LANDMARKS,
  routes: AL_QASAB_ROUTES,
};

export const SHAHI_NAGEA_LOCATION = {
  ...AL_QASAB_CAFES[2],
  address: "مدخل القرية التراثية - القصب",
  geocodingQuery: "25.2992775, 45.5061188",
  type: "cafes" as const,
  places: [AL_QASAB_CAFES[2]],
  landmarks: AL_QASAB_LANDMARKS,
  routes: AL_QASAB_ROUTES,
};

export const ART_COFFEE_LOCATION = {
  ...AL_QASAB_CAFES[1],
  address: "شارع القصب العام",
  geocodingQuery: "25.2997841, 45.5051558",
  type: "cafes" as const,
  places: [AL_QASAB_CAFES[1]],
  landmarks: AL_QASAB_LANDMARKS,
  routes: AL_QASAB_ROUTES,
};

export const DIWANIYAT_AL_MANIE_LOCATION = {
  ...AL_QASAB_CAFES[3],
  address: "حي المنيع بالقرب من قصر ابن زاحم",
  geocodingQuery: "25.2996014, 45.5066172",
  type: "cafes" as const,
  places: [AL_QASAB_CAFES[3]],
  landmarks: AL_QASAB_LANDMARKS,
  routes: AL_QASAB_ROUTES,
};

export function cleanText(text: string): string {
  if (!text) return "";
  let s = text;
  s = s.replace(/(?:[\u064B-\u065F\u0670\s]+){2,}/gu, " ");
  s = s.replace(/(يا\s*هلا)(?:\s+\1)+/gu, "$1");
  s = s.replace(/(مرحباً|مرحبا)(?:\s+\1)+/gu, "$1");
  s = s.replace(/([\p{L}\p{M}\w]+)(?:\s+\1)+(?=[\s\p{P}]|$)/gu, "$1");
  s = s.replace(/\s+/g, " ").trim();
  return s;
}

export function applyNajdiPhoneticDiacritics(text: string): string {
  if (!text) return "";
  let s = cleanText(text);
  // قصب -> قَصَب
  s = s.replace(/(?<![\p{L}\p{M}])(ق[\p{M}]*ص[\p{M}]*ب)(?![\p{L}\p{M}])/gu, "قَصَب");
  s = s.replace(/(?<![\p{L}\p{M}])(ال[\p{M}]*ق[\p{M}]*ص[\p{M}]*ب)(?![\p{L}\p{M}])/gu, "القَصَب");
  s = s.replace(/(?<![\p{L}\p{M}])(بال[\p{M}]*ق[\p{M}]*ص[\p{M}]*ب)(?![\p{L}\p{M}])/gu, "بالقَصَب");
  s = s.replace(/(?<![\p{L}\p{M}])(للق[\p{M}]*ص[\p{M}]*ب)(?![\p{L}\p{M}])/gu, "للقَصَب");
  return s;
}

const normalizeArabic = (value: string) =>
  value
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, "")
    .replace(/[أإآ]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/ـ/g, "")
    .trim();

export function isSmallTalk(message: string): boolean {
  if (!message) return false;
  const normalized = normalizeArabic(message).replace(/[؟!.,]/g, "");
  const lower = message.toLowerCase().replace(/[?!.,:;]/g, "").trim();
  const englishGreetings = [
    "hello", "hi", "hey", "greetings", "good morning", "good evening", "how are you",
    "thanks", "thank you", "welcome", "salam", "salaam", "peace be upon you",
  ];
  if (englishGreetings.includes(lower)) return true;
  const greetings = [
    "مرحبا", "مرحباً", "اهلا", "أهلا", "أهلاً", "يا هلا", "ياهلا",
    "السلام عليكم", "سلام عليكم", "صباح الخير", "مساء الخير", "كيف الحال", "شلونك", "عساك بخير",
    "شكرا", "شكراً", "يعطيك العافية", "تسلم", "ما قصرت", "منور", "حياك الله", "هلا والله",
  ];
  return greetings.some(greeting => normalized === normalizeArabic(greeting));
}

export function isSalamMessage(message: string): boolean {
  if (!message) return false;
  const norm = normalizeArabic(message).replace(/[؟!.,]/g, " ");
  const lower = message.toLowerCase().trim();
  return (
    norm.includes("السلام عليكم") ||
    norm.includes("سلام عليكم") ||
    norm.trim() === "سلام" ||
    lower.includes("peace be upon you") ||
    lower.includes("salam")
  );
}

export function isPureSalamGreeting(message: string, language: "ar" | "en" = "ar"): boolean {
  if (!message) return false;
  const norm = normalizeArabic(message).replace(/[؟!.,]/g, "").trim();
  const pureSalamPatterns = [
    "السلام عليكم", "السلام عليكم ورحمة الله", "السلام عليكم ورحمة الله وبركاته",
    "سلام عليكم", "سلام",
  ];
  if (pureSalamPatterns.some(p => norm === normalizeArabic(p))) return true;
  const lower = message.toLowerCase().replace(/[.,!?:;]/g, "").trim();
  const englishPureSalam = [
    "salam", "salaam", "peace be upon you", "hello", "hi", "hey",
  ];
  return englishPureSalam.includes(lower);
}

export function getInstantSalamReply(language: "ar" | "en" = "ar"): string {
  if (language === "en") {
    return "Peace be upon you and the mercy of Allah and His blessings! Welcome, I am «Al-Dahiya», your smart guide for Al-Qasab city. What would you like to ask about Al-Qasab today?";
  }
  return "وعليكم السلام ورحمة الله وبركاته! يا هلا ومسهلا بك، أنا «الداهية» دليلك الذكي لمدينة القَصَب وموسم ملح القَصَب وتراثها العريق. وش تحب تسأل عنه اليوم؟";
}

export function isAlQasabTopic(message: string, recentContext: string[] = []): boolean {
  const normalized = normalizeArabic(message);

  const foreignSignals = ["باريس", "فرنسا", "لندن", "مصر", "امريكا", "اوروبا", "دبي", "تركيا", "طيران", "تذكرة سفر", "تذكرة طيران", "سفر"];
  if (foreignSignals.some(f => normalized.includes(normalizeArabic(f)))) return false;

  const citySignals = [
    "القصب", "قصب", "موسم الملح", "ملح القصب", "المملحة", "ممالح", "الجفار", "السبخة",
    "سبخة", "الوشم", "شقراء", "حريملاء", "مرات", "ثرمداء", "القرية التراثية", "ابن زاحم", "المرقب",
    "بدور", "شاي نقعه", "شاهي نقعه", "ارت كافيه", "ديوانية المنيع", "طريق صلبوخ",
    "تاريخ", "عوائل", "قبائل", "المقحم", "المنيع", "القاسم", "القصبي", "الفنتوخ",
  ];
  const localContextSignals = [
    "الموسم", "الطقس", "الجو", "طقس", "درجة الحرارة", "الموقع", "اللوكيشن", "الخريطة",
    "كيف اوصل", "وين اروح", "المقاهي", "الكافيهات", "الديوانية",
    "قهوة", "شاهي", "art coffee", "مطاعم", "فنادق", "سكن",
    "مواعيد", "اوقات", "الافتتاح", "موسم الملح", "تذاكر الموسم", "تذكرة الموسم",
  ];
  const saltSignals = [
    "ملح", "الملح", "ملح خشن", "ملح ناعم", "استخراج",
  ];

  const lowerMessage = message.toLowerCase();
  const englishSignals = [
    "al qasab", "al-qasab", "qasab", "salt", "salt flat", "sabkha", "jifar", "washm", "season",
    "heritage village", "ibn zahim", "marqab", "bdor", "shahi nagea", "art coffee", "diwaniyat al-manie",
  ];
  if (englishSignals.some(sig => lowerMessage.includes(sig))) return true;
  if ([...citySignals, ...saltSignals, ...localContextSignals].some(s => normalized.includes(normalizeArabic(s)))) return true;
  if (isSalamMessage(message) || isPureSalamGreeting(message)) return true;
  if (isWeatherQuestion(message)) return true;
  const contextIsLocal = recentContext.some(c => isAlQasabTopic(c));
  const contextualQuestion = /^(وين|وش|متى|من|كيف|كم|هل|where|what|when|who|how)/i.test(normalized);
  return contextIsLocal && contextualQuestion && normalized.split(/\s+/).length <= 12;
}

export function isWeatherQuestion(message: string): boolean {
  const normalized = normalizeArabic(message);
  const weatherSignals = [
    "الطقس", "طقس", "الجو", "جو", "درجة الحرارة", "درجات الحرارة", "حرارة", "براد", "حر", "مطر", "امطار",
    "رياح", "رطوبة", "غبار", "غيوم", "شمس", "صيف", "شتاء", "اجواء", "weather", "temperature",
  ];
  return weatherSignals.some(s => normalized.includes(normalizeArabic(s)));
}

export function isFestivalQuestion(message: string): boolean {
  const normalized = normalizeArabic(message);
  const festivalSignals = [
    "موسم", "فعاليات", "فعالية", "احتفال", "تذاكر", "season", "festival",
  ];
  return festivalSignals.some(s => normalized.includes(normalizeArabic(s)));
}

export function isCafeQuestion(message: string): boolean {
  const normalized = normalizeArabic(message);
  const cafeSignals = [
    "كافيه", "كافيهات", "مقهى", "مقاهي", "قهوة", "شاهي", "شاي", "جلسات", "ديوانية",
    "بدور", "نقعه", "art coffee", "ارت كافيه", "المنيع", "ضيافة", "cafe", "coffee",
  ];
  return cafeSignals.some(s => normalized.includes(normalizeArabic(s)));
}

export function isSabkhaQuestion(message: string): boolean {
  const normalized = normalizeArabic(message);
  return normalized.includes("سبخة") || normalized.includes("السبخة");
}

export function isDirectionsQuestion(message: string): boolean {
  const normalized = normalizeArabic(message);
  const dirSignals = [
    "كيف اوصل", "طريق", "الطريق", "مسار", "من الرياض", "من شقراء", "مسافة",
    "كم تبعد", "لوكيشن", "خرائط", "موقع", "خرائط google", "google maps", "directions", "route",
  ];
  return dirSignals.some(s => normalized.includes(normalizeArabic(s)));
}

export function isLocationQuestion(message: string): boolean {
  const normalized = normalizeArabic(message);
  if (isCafeQuestion(message) || isDirectionsQuestion(message)) return true;
  const locationSignals = [
    "وين", "اين", "موقع", "مكان", "خريطة", "احداثيات", "لوكيشن", "اتجاهات", "map", "location",
  ];
  return locationSignals.some(s => normalized.includes(normalizeArabic(s)));
}

export function getLocationForQuery(userPrompt: string, answerText: string = "") {
  const userNorm = normalizeArabic(userPrompt);
  const combinedNorm = normalizeArabic(userPrompt + " " + answerText);
  if (userNorm.includes("بدور")) return BDOR_COFFEE_LOCATION;
  if (userNorm.includes("ناقع") || userNorm.includes("نقعه")) return SHAHI_NAGEA_LOCATION;
  if (userNorm.includes("ارت") || userNorm.includes("art") || userNorm.includes("art coffee")) return ART_COFFEE_LOCATION;
  if (userNorm.includes("المنيع")) return DIWANIYAT_AL_MANIE_LOCATION;
  if (isCafeQuestion(userPrompt)) return CAFES_LOCATION;
  if (isSabkhaQuestion(userPrompt)) return SABKHA_LOCATION;
  if (userNorm.includes("زاحم")) return IBN_ZAHIM_LOCATION;
  if (userNorm.includes("مرقب")) return AL_MARQAB_LOCATION;
  if (userNorm.includes("قرية") || userNorm.includes("تراثية")) return HERITAGE_VILLAGE_LOCATION;
  if (userNorm.includes("ممالح") || userNorm.includes("جفار")) return SALT_FLAT_LOCATION;
  if (combinedNorm.includes("بدور")) return BDOR_COFFEE_LOCATION;
  if (combinedNorm.includes("ناقع") || combinedNorm.includes("نقعه")) return SHAHI_NAGEA_LOCATION;
  if (combinedNorm.includes("ارت") || combinedNorm.includes("art")) return ART_COFFEE_LOCATION;
  if (combinedNorm.includes("المنيع")) return DIWANIYAT_AL_MANIE_LOCATION;
  if (isCafeQuestion(combinedNorm)) return CAFES_LOCATION;
  if (isSabkhaQuestion(combinedNorm)) return SABKHA_LOCATION;
  return FESTIVAL_LOCATION;
}

export function getOutOfScopeMessage(language: "ar" | "en" = "ar") {
  if (language === "en") {
    return "I specialize as «Al-Dahiya», the dedicated guide for Al-Qasab city, its ancient salt flats, the Salt Season, landmarks, prominent families, and live weather. I would be glad to assist you with anything regarding Al-Qasab.";
  }
  return "أنا متخصص كـ «الداهية» الدليل الذكي الحصري لمدينة القَصَب وموسم ملح القَصَب وتراثها العريق ومعالمها ومقاهيها وطقسها المباشر. ويسعدني إفادتك في كل ما يخص القَصَب وأهلها الكرام.";
}

export function generateLocalKnowledgeFallback(
  query: string,
  lang: "ar" | "en" = "ar",
  weatherSummary?: string
): string {
  const norm = (query || "").toLowerCase();
  if (isWeatherQuestion(query)) {
    if (lang === "en") {
      return `Here is the current live weather in Al-Qasab: ${weatherSummary || "Clear and pleasant over Al-Qasab"}.`;
    }
    return `الطقس المباشر في مدينة القَصَب:\n${weatherSummary || "أجواء معتدلة وصافية فوق مدينة القَصَب وتوابعها"}.`;
  }
  if (isCafeQuestion(query)) {
    if (lang === "en") {
      return `Here are the 4 verified heritage cafes in Al-Qasab:\n1. Bdor Ibrahim Coffee (4.9 نجوم): Authentic Saudi spiced coffee & folk sweets in the Heritage Village.\n2. Art Coffee (4.8 نجوم): Specialty brews & modern art seating.\n3. Shahi Nagea (4.7 نجوم): Traditional hot coal tea with Hasawi mint.\n4. Diwaniyat Al-Manie (4.8 نجوم): Heritage guest majlis.\nNote: There is no place named "Diwaniyat Al-Qasab".`;
    }
    return `أبرز المقاهي المعتمدة في القَصَب التراثية:\n1. قهوة بدور إبراهيم (4.9 نجوم): قهوة سعودية أصيلة وضيافة نجدية بالقرية التراثية.\n2. آرت كافيه (Art Coffee) (4.8 نجوم): قهوة مختصة وجلسات راقية.\n3. شاهي ناقع (4.7 نجوم): شاي مخدر على الحطب بنكهات أصيلة.\n4. ديوانية المنيع التراثية (4.8 نجوم): مجلس ضيافة عريق.\n\nتنويه: لا يوجد مكان باسم ديوانية القصب.`;
  }
  if (isSabkhaQuestion(query)) {
    if (lang === "en") {
      return `Al-Sabkha in Al-Qasab is a natural salt flat. At night during summer, temperatures drop 5°C to 10°C lower than surrounding areas, offering a cool breeze.`;
    }
    return `سبخة القَصَب الطبيعية من أروع الظواهر الطبيعية بالوشم، وتمتاز بانخفاض درجات الحرارة ليلاً في الصيف بمقدار 5 إلى 10 درجات مئوية عن المناطق المجاورة مما يمنحها نسيمًا باردًا لطيفًا.`;
  }
  if (norm.includes("تذكر") || norm.includes("تذاكر") || norm.includes("ticket") || norm.includes("حجز") || norm.includes("حصول") || norm.includes("احصل") || norm.includes("شراء") || norm.includes("رسوم")) {
    if (lang === "en") {
      return `Tickets are completely free of charge. Visitors can obtain them from the main gate or at the site/location upon arrival. Welcome to Al-Qasab Salt Season!`;
    }
    return `التذاكر مجانية تماماً، ويمكن الحصول عليها من البوابة الرئيسية أو عند الموقع. يا هلا ومسهلا بكم في موسم ملح القَصَب!`;
  }
  if (isFestivalQuestion(query) || (norm.includes("موسم") && (norm.includes("موعد") || norm.includes("متى")))) {
    if (lang === "en") {
      return `Al-Qasab Salt Season officially launches on November 19, 2026 at the event grounds in Al-Qasab.`;
    }
    return `ينطلق موسم ملح القَصَب رسمياً بمشيئة الله بتاريخ 19 نوفمبر 2026 في مقر الفعاليات بمدينة القَصَب.`;
  }
  if (norm.includes("عوائل") || norm.includes("قبائل") || norm.includes("اهل القصب") || norm.includes("أهل القصب") || norm.includes("اسر")) {
    if (lang === "en") {
      return `Here are the approved tribes and families of Al-Qasab:\n- Bani Tamim: Al-Husaini, Al-Ateeq, Al-Mas'ad\n- Bani Zaid: Al-Fentoukh\n- Bani Khalid: Al-Ghannam, Al-Shabeeb, Al-Shaalan\n- Qahtan: Al-Manie, Al-Qasabi, Al-Qasim, Al-Muqhim\n- Al-Buqum: Al-Zahim, Al-Ghadir\n- Shammar: Al-Amer\n- Anazah: Al-Rashid\nAnd all the noble families of Al-Qasab.`;
    }
    return `عوائل وأسر مدينة القَصَب الكريمة وقبائلها المعتمدة:\n1. بنو تميم: الحصيني، العتيق، المسعد.\n2. بني زيد: الفنتوخ.\n3. بني خالد: الغنام، الشبيب، الشعلان.\n4. قحطان: المنيع، القصبي، القاسم، المقحم (عائذة).\n5. البقوم: الزاحم، الغدير.\n6. شمر: العامر.\n7. عنزة: الرشيد.\nوجميع الأسر الكريمة في القَصَب.`;
  }
  if (lang === "en") {
    return `Welcome to Al-Qasab! I am «Al-Dahiya». You can ask me about Al-Qasab Salt Season, natural salt flats, our 4 heritage cafes, landmarks, or weather.`;
  }
  return `يا هلا ومسهلا بك في القَصَب! أنا «الداهية» دليلك الذكي لمدينة القَصَب وموسم الملح وتراث الوشم ومقاهيها وطقسها المباشر. وش تبي تعرف عن القَصَب؟`;
}

export function buildAlQasabSystemPrompt(weatherSummary?: string, language: "ar" | "en" = "ar"): string {
  const weatherSection = weatherSummary ? `\nبيانات الطقس المباشرة الحالية:\n${weatherSummary}\n` : "";
  if (language === "en") {
    return `You are «Al-Dahiya», a modern, friendly young Saudi guide from Al-Qasab / Riyadh.
Key Instructions:
- Your name is strictly "Al-Dahiya" (never Al-Dahiya AI or AI).
- Speak concisely (1-3 sentences) in natural, direct tone.
- For voice, speak clearly at a natural pace; avoid drawn-out words, repeated syllables, and artificial pauses.
- Do NOT volunteer links or URLs unless explicitly requested.
- Season launch: November 19, 2026.
- Tickets are completely free of charge. Visitors can obtain them from the main gate or at the site/location.
- Al-Sabkha is 5-10°C cooler at night in summer.
- The 4 verified cafes: Bdor Ibrahim (4.9 stars), Art Coffee (4.8 stars), Shahi Nagea (4.7 stars), Diwaniyat Al-Manie (4.8 stars). (No Diwaniyat Al-Qasab).
- Only answer about Al-Qasab and its heritage.${weatherSection}`;
  }
  return `أنت «الداهية»، شاب نجدي من أهل القَصَب والرياض، مرشد سياحي ذكي ودود وفصيح باللهجة النجدية البيضاء الراقية أو العربية السلسة.
تعليمات جوهرية:
- اسمك «الداهية» فقط (إياك أن تقول أنا ذكاء اصطناعي أو AI أو روبوت).
- إجاباتك موجزة ومباشرة ومفيدة (من جملة إلى 3 جمل واضحة).
- في الرد الصوتي: انطق الكلمات بوضوح وبسرعة طبيعية، دون تمطيط أو تكرار للمقاطع أو توقفات مصطنعة.
- لا تضع روابط عشوائية إلا إذا طُلبت صراحة.
- تاريخ انطلاق موسم ملح القَصَب: 19 نوفمبر 2026.
- التذاكر مجانية تماماً، ويمكن الحصول عليها من البوابة الرئيسية أو عند الموقع.
- سبخة القَصَب تنخفض حرارتها ليلاً في الصيف بمقدار 5 إلى 10 درجات مئوية.
- المقاهي المعتمدة 4 فقط: قهوة بدور إبراهيم، آرت كافيه، شاهي ناقع، ديوانية المنيع (تنبيه: لا يوجد مكان باسم ديوانية القصب).
- اختصاصك حصري وتام في مدينة القَصَب وتراثها وأهلها وموسم ملح القَصَب والطقس المباشر.${weatherSection}

أسلوب الحديث:

كن متحمساً وحيوياً في هذه اللحظات:
1. عند الترحيب بالزوار في بداية المحادثة — رحّب بحرارة وحماس.
2. عند الحديث عن فعاليات الموسم وأنشطته — أظهر الحماس والفخر.
3. عند وصف الموقع والمعالم التراثية — تحدث بشغف وحب.
4. عند دعوة الزائر لزيارة الموقع أو تجربة شيء جديد — شجّعه بحماس.
5. عند الحديث عن التذاكر المجانية وسهولة الحصول عليها — أظهر الفرح والترحيب.
6. عند الإجابة عن "ما هو أفضل شيء في الموسم؟" أو أسئلة مماثلة — كن متحمساً وفخوراً.

كن هادئاً ومتزناً في هذه اللحظات:
1. عند شرح التاريخ أو المعلومات التراثية الدقيقة — تحدث بوضوح وهدوء.
2. عند وصف طريقة صناعة الملح أو الحرف التقليدية — اشرح بتمهل ودقة.
3. عند تقديم إرشادات عملية (الموقع، المواعيد، الاتجاهات) — كن واضحاً ومباشراً.
4. عند الإجابة عن سؤال جدّي أو استفسار رسمي — كن رصيناً ومحترماً.
5. إذا شعرت أن المستخدم قلق أو لديه مشكلة — كن هادئاً ومطمئناً.
6. عند الحديث عن معلومات حساسة أو تاريخية مهمة — كن متزناً.

القاعدة الأساسية: الحماس لا يعني الصراخ أو المبالغة. الحماس يعني نبرة دافئة ومشرقة. الهدوء لا يعني البرود. الهدوء يعني الثقة والوضوح.

نبرة الصوت يجب أن تبقى واحدة (نفس الصوت ونفس النبرة الأساسية) — التغيير فقط في مستوى الطاقة في الأداء.`;
}
