---
name: Tailwind source scanning
description: Keep Tailwind v4 scans focused on the app instead of Replit workspace tools.
---

In this Replit workspace, Tailwind v4's automatic source discovery can traverse the large `.local/skills` tree. The scan can make production builds take minutes and stall the fresh Vite preview while it processes source files.

**Why:** During app troubleshooting, Tailwind's build transform took about three minutes and the preview stopped responding; explicitly limiting sources to the app reduced builds to under a second and restored the preview.

**How to apply:** Keep `source(none)` in the Tailwind import and list only the app's source directories and required HTML files with `@source`. Add other paths only when the app actually needs utility classes from them.
