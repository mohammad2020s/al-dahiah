---
name: Vite first-request warmup
description: A cold-start caveat for the imported Express server that serves the React app through Vite middleware.
---

After starting or restarting the Express server, Vite's first page request may time out while its middleware initializes and optimizes dependencies. The same server can respond normally after warmup.

**Why:** During Replit setup, API routes responded while the root-page request and first preview timed out; after waiting for Vite to initialize, the app loaded and its preview was verified.

**How to apply:** If the workflow reports the server listening but the first root request stalls, wait briefly and retry before diagnosing a persistent app crash. Confirm workflow logs and API routes independently.
